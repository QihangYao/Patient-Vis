# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 10:54:43 2019

@author: zhn
"""

from flask import (Flask, url_for, request, render_template, flash, jsonify, redirect)

app = Flask(__name__)

@app.route('/haha', methods = ['GET', 'POST'])
def haha():
    if request.method == "POST":
        print('should be hello')
        redirect(url_for('hello'))
    return render_template("query-1.html")
    #return 'haha'

@app.route('/hello', methods = ['GET', 'POST'])
def hello():
    if request.method == "POST":
        print('should be haha')
        redirect(url_for('haha'))
    return render_template("query.html")
    #return 'hello'

@app.route('/')
def turn():
    print('redirect')
    return redirect(url_for('hello'))

if __name__ == '__main__':
    app.run()