DROP TABLE IF EXISTS patient;
DROP TABLE IF EXISTS admissions;

CREATE TABLE patient (
    index INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL
);

CREATE TABLE admissions (
    index INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    hadm_id INTEGER NOT NULL
    --admittime DATE 
)