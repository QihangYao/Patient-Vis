# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 11:05:31 2019

@author: zhn
"""
import os
from pyathena import connect
from flask import (Flask, url_for, request, render_template, flash, jsonify, redirect)
from backend import create_patient_dict, init_patient_list
import db  

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

aws_access_key_id = "AKIAUXPGEYVLHD4JGCSV"
aws_secret_access_key = "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"
s3_staging_dir = "s3://mimiciii-query-result/"
region_name = "us-east-1"
    
conn = connect(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        s3_staging_dir=s3_staging_dir,
        region_name=region_name,
        schema_name="mimiciii",
    )

@app.route('/patient_info_query', methods = ["GET", "POST"])
def patient_info_query():
    if request.method == 'POST':
        patient_id = request.json["text"]
        print('receive success!')
        print(patient_id)
        error = None
        
        db_conn = db.get_db()
        hadm_id = db_conn.execute("select hadm_id from ADMISSION where patient_id = ?", (patient_id, )).fetchone()
        
        if hadm_id is None:
            error = "Input patient ID doesn't exist."
        
        if error is None:
            hadm_cursor = db_conn.execute("select hadm_id from ADMISSION where patient_id = ?", (patient_id, ))
            hadm_list = []
            for row in hadm_cursor:
                hadm_list.append(row[0])
            return jsonify(hadm_list)
        
        flash(error)
        
       
    return render_template("query-remake.html")

@app.route('/visualization', methods = ["GET", "POST"])
def visualization():
    print('visualization')
    patient_info = [('222', '103002'), ('250', '124271')]
    '''
    if request.method == "POST":
        # select by drop list
        patient_index = request.json['selected']
        patient_id, hadm_id = patient_info[patient_index]
        print(patient_id)
        print(hadm_id)
        error = None
        # check if it is valid
        if error is None:
            file_name = "test.json"
            # first check if the data has been saved into database
            #file_name = create_patient_dict(conn, patient_id, hadm_id)
            return render_template('patient-vis-v2.html', fileName = file_name)
            '''
    #return render_template('patient-vis-v2.html', fileName = "test.json")
    return render_template('patient-vis-v2.html')

@app.route('/patient_query', methods = ["GET", "POST"])
def patient_query():
    if request.method == "POST":
        patient_id = request.json["patient_id"]
        hadm_id = request.json["hadm_id"]
        error = None
        if error is None:
            file_name = create_patient_dict(conn, patient_id, hadm_id)
            print('redirecting to visaulization.')
            return redirect(url_for('.visualization'))
    return render_template("query-remake.html")



@app.route('/')
def initialize():
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass
    
    app.config.from_mapping(
        # a default secret that should be overridden by instance config
        SECRET_KEY="dev",
        # store the database in the instance folder
        DATABASE=os.path.join(app.instance_path, "flaskr.sqlite"),
    )
    db.init_app(app)
    db.init_db()
    db_conn = db.get_db()
    # initialize patient data
    init_patient_list(conn, db_conn)
    
    return render_template("query-remake.html")

    
if __name__ == '__main__':
    app.run()